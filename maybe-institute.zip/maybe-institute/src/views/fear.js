window.MI = window.MI || {};
(function (MI) {
  'use strict';
  MI.views = MI.views || {};

  var d = MI.dom;
  var thinking = false;

  var CARE_TEXT = '我停一下。\n\n' +
    '刚才那句话里，有些东西超出了这个作品能接住的范围。这里只是一个用你自己的记录拼出来的声音，' +
    '它说的不是事实，也不该由它来陪你面对这种时刻。\n\n' +
    '如果你此刻感到难以承受，请把它告诉一个你信任的人；如果情况紧急，请联系当地的专业心理支持或急救服务。' +
    '你不需要独自处理这件事。';

  function render() {
    return '' +
      '<section class="page">' +
      '<div class="page-head">' +
      '<div class="eyebrow">THE FEAR MODEL &nbsp;/&nbsp; 用你的痕迹蒸馏出来的声音</div>' +
      '<h1 class="page-title">恐惧模型</h1>' +
      '<p class="page-desc">它不是通用毒舌机器人，也不是心理测评。' +
      '它的每一句话都来自你在这个作品里留下的真实痕迹：写过的念头、说过太难的任务、判断过不像你的路线。' +
      '它唯一的进化方向是越辩越弱——你认真反驳，它的确定性就会下降。</p>' +
      '</div>' +

      '<div class="warn-box" style="margin-bottom:20px">' +
      '<strong>在开始之前</strong>' +
      '这里的对话不是心理咨询、不是诊断，也不能替代专业帮助。它模拟的是「那个拦住你的声音」，' +
      '目的是让你看清它、反驳它，而不是相信它。所有对话只保存在本浏览器。' +
      '如果你正处在情绪危机中，请优先联系你信任的人或专业心理支持。' +
      '</div>' +

      '<div class="fear-layout">' +
      '<div class="chat-panel">' +
      '<div class="chat-log" id="chat-log" role="log" aria-live="polite" aria-label="与恐惧模型的对话"></div>' +
      '<form class="chat-form" id="chat-form">' +
      '<label class="sr-only" for="chat-text">说点什么，反驳它</label>' +
      '<textarea id="chat-text" maxlength="400" placeholder="说点什么，反驳它。它只能听懂你写在这里的东西。"></textarea>' +
      '<div class="chat-actions">' +
      '<span class="chat-count" id="chat-count">0 / 400</span>' +
      '<button class="btn btn-primary" type="submit" id="chat-send">说回去</button>' +
      '</div>' +
      '</form>' +
      '<p class="chat-hint" id="chat-hint">它说的不是事实。它只是你最熟悉的那种声音。</p>' +
      '</div>' +

      '<aside>' +
      '<div class="panel">' +
      '<div class="panel-head"><div><h2>蒸馏报告</h2>' +
      '<p>它由什么构成。每一句都能追溯到一条真实数据。</p></div></div>' +
      '<div class="meter-list" id="meters"></div>' +
      '<div class="fact-list" id="corpus-list"></div>' +
      '<div class="archetype-list" id="archetype-list"></div>' +
      '<div id="distill-actions"></div>' +
      '</div>' +

      '<div class="panel">' +
      '<div class="panel-head"><div><h2>它的自进化</h2>' +
      '<p>每次你表态，它都会重新计算自己的确定性与压迫感。</p></div>' +
      (MI.store.get().fear.model.log.length ? '<button class="text-btn" id="reset-fear">重置这段对话</button>' : '') +
      '</div>' +
      '<div id="fear-log"></div>' +
      '</div>' +
      '</aside>' +
      '</div>' +
      '</section>';
  }

  // ── 局部渲染 ────────────────────────────────────────
  function paintLog(root) {
    var turns = MI.fear.turns();
    var log = root.querySelector('#chat-log');

    if (!turns.length) {
      log.innerHTML = '<p class="chat-empty">它还没有开口。点下面的按钮，让它说出第一句。</p>';
      return;
    }

    log.innerHTML = turns.map(function (t, i) {
      if (t.role === 'you') {
        return '<div class="chat-turn you"><p>' + d.esc(t.text) + '</p></div>';
      }
      if (t.role === 'care') {
        return '<div class="chat-turn care">' +
          '<div class="chat-meta"><span>事务所</span></div>' +
          '<p>' + d.esc(t.text).replace(/\n/g, '<br>') + '</p></div>';
      }
      var arch = t.archetype && MI.fear.ARCHETYPES[t.archetype]
        ? MI.fear.ARCHETYPES[t.archetype].label
        : (t.archetype || '恐惧');
      var badge = t.engine === 'ai' ? '模型' : t.engine === 'distilled' ? '蒸馏' : '原型';
      return '<div class="chat-turn fear">' +
        '<div class="chat-meta"><span>' + d.esc(arch) + '</span>' +
        '<span class="engine-badge">' + badge + '</span></div>' +
        '<p>' + d.esc(t.text).replace(/\n/g, '<br>') + '</p>' +
        '<div class="seg compact" role="group" aria-label="对这句话的反应">' +
        MI.data.FEAR_VERDICTS.map(function (v) {
          return '<button data-verdict="' + v.key + '" data-turn="' + i + '" aria-pressed="' +
            (t.verdict === v.key) + '">' + d.esc(v.label) + '</button>';
        }).join('') +
        '</div></div>';
    }).join('');

    log.scrollTop = log.scrollHeight;
  }

  function paintReport(root) {
    var der = MI.fear.derive();
    var stats = MI.store.get().fear.stats;
    var c = MI.fear.corpus();

    root.querySelector('#meters').innerHTML =
      meter('确定性', der.certainty, Math.round(der.certainty * 100) + '%') +
      meter('压迫感', der.pressure, Math.round(der.pressure * 100) + '%') +
      meter('击中 ' + stats.hit + ' · 反驳 ' + stats.rebut + ' · 回避 ' + stats.avoid, 0, '', true);

    root.querySelector('#corpus-list').innerHTML = [
      ['写下的念头', c.ideas + ' 个'],
      ['判断过的路线', c.feedbackRoutes.length + ' 条'],
      ['评价过的任务', c.feedbackTasks.length + ' 条'],
      ['完成过的天数', MI.fear.totalCompletedDays() + ' 天'],
      ['对话轮数', c.turns + ' 轮']
    ].map(function (row) {
      return '<div class="fact"><span class="fact-label">' + d.esc(row[0]) + '</span>' +
        '<span class="fact-value">' + d.esc(row[1]) + '</span><span style="width:14px"></span></div>';
    }).join('');

    var max = Math.max.apply(null, MI.fear.archetypes().map(function (a) { return a.weight; }).concat([1]));
    root.querySelector('#archetype-list').innerHTML =
      '<div class="archetype-title">它手里的牌</div>' +
      MI.fear.archetypes().sort(function (a, b) { return b.weight - a.weight; }).map(function (a) {
        var focused = der.focus === a.key;
        return '<div class="archetype' + (focused ? ' focused' : '') + '">' +
          '<div class="archetype-head"><span>' + d.esc(a.label) + '</span>' +
          '<span class="archetype-weight">' + a.weight.toFixed(1) + '</span></div>' +
          '<div class="bar-track"><span class="bar-fill" style="width:' +
          Math.round(a.weight / max * 100) + '%;background:' + (focused ? 'var(--orange)' : '#c9cfbc') + '"></span></div>' +
          '<p class="archetype-evidence">依据：' + d.esc(a.evidence) + '</p>' +
          '</div>';
      }).join('');

    var dis = MI.store.get().fear.distilled;
    var actions = [];
    if (dis) {
      actions.push('<div class="distill-note">已于 ' + d.esc(d.relativeDay(dis.at)) +
        ' 用模型重新蒸馏：' + d.esc(dis.summary || '（无摘要）') + '</div>');
    }
    if (MI.ai.isConfigured()) {
      actions.push('<button class="btn btn-ghost btn-block" id="distill-btn" style="margin-top:12px">' +
        (dis ? '再蒸馏一次' : '用模型重新蒸馏') + '</button>');
    } else {
      actions.push('<p class="hint" style="margin-top:12px">当前是本地蒸馏。' +
        '在设置里接入模型后，可以让它把这份画像说得更准。</p>');
    }
    root.querySelector('#distill-actions').innerHTML = actions.join('');
  }

  function meter(label, value, text, plain) {
    if (plain) return '<div class="meter-plain">' + d.esc(label) + '</div>';
    return '<div class="meter">' +
      '<div class="meter-head"><span>' + d.esc(label) + '</span><span>' + d.esc(text) + '</span></div>' +
      '<div class="bar-track"><span class="bar-fill" style="width:' + Math.round(value * 100) + '%"></span></div>' +
      '</div>';
  }

  function paintFearLog(root) {
    var log = MI.store.get().fear.model.log.slice().reverse();
    root.querySelector('#fear-log').innerHTML = log.length ? log.map(function (l) {
      return '<div class="evo-item">' +
        '<p class="evo-trigger">' + d.esc(l.trigger) + '</p>' +
        '<p class="evo-change">' + d.esc(l.change) + '</p>' +
        '<p class="evo-meta">REV ' + l.revision + ' &nbsp;·&nbsp; ' + d.esc(d.relativeDay(l.date)) + '</p>' +
        '</div>';
    }).join('') : '<p class="page-desc">还没有变化。你每表一次态，它都会重新算一遍自己站不站得住。</p>';
  }

  function paintAll(root) {
    paintLog(root);
    paintReport(root);
    paintFearLog(root);
    MI.app.syncCounts();
  }

  // ── 对话推进 ─────────────────────────────────────────
  function respond(root, userText) {
    if (thinking) return;
    thinking = true;
    var send = root.querySelector('#chat-send');
    send.disabled = true;
    send.textContent = '它在想…';

    var finish = function () {
      thinking = false;
      send.disabled = false;
      send.textContent = '说回去';
      paintAll(root);
    };

    var useLocal = function (note) {
      var reply = MI.fear.compose();
      MI.fear.addTurn('fear', reply.text, reply.archetype, reply.engine);
      if (note) d.toast(note, 4600);
      finish();
    };

    if (!MI.ai.isConfigured()) { useLocal(); return; }

    MI.ai.converse(userText, MI.fear.promptContext()).then(function (text) {
      MI.fear.addTurn('fear', text, MI.fear.derive().focus || 'who_are_you', 'ai');
      finish();
    }).catch(function (err) {
      useLocal('模型没能回答（' + err.message + '），已用它本地的声音继续。');
    });
  }

  function mount(root) {
    var input = root.querySelector('#chat-text');
    var count = root.querySelector('#chat-count');

    if (!MI.fear.turns().length) {
      var open = MI.fear.opening();
      if (open) MI.fear.addTurn('fear', open.text, open.archetype, open.engine);
    }
    paintAll(root);

    input.addEventListener('input', function () {
      count.textContent = input.value.length + ' / 400';
    });

    root.querySelector('#chat-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var text = input.value.trim();
      if (!text) {
        d.toast('哪怕只写一句，也算把它说回去了。');
        input.focus();
        return;
      }
      MI.fear.addTurn('you', text);
      input.value = '';
      count.textContent = '0 / 400';

      if (MI.fear.detectCrisis(text)) {
        MI.fear.addTurn('care', CARE_TEXT);
        paintAll(root);
        return;
      }
      paintLog(root);
      respond(root, text);
    });

    input.addEventListener('keydown', function (e) {
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
        e.preventDefault();
        root.querySelector('#chat-form').requestSubmit();
      }
    });

    root.querySelector('#chat-log').addEventListener('click', function (e) {
      var btn = e.target.closest('[data-verdict]');
      if (!btn) return;
      MI.fear.rateTurn(Number(btn.dataset.turn), btn.dataset.verdict);
      paintAll(root);
      var map = { hit: '记下了。它会记住这句话对你有效。', rebut: '记下了。它的确定性下降了。', avoid: '记下了。它会盯得更紧一点。' };
      d.toast(map[btn.dataset.verdict] || '记下了。');
    });

    root.querySelector('#distill-actions').addEventListener('click', function (e) {
      if (!e.target.closest('#distill-btn')) return;
      var btn = root.querySelector('#distill-btn');
      btn.disabled = true;
      btn.textContent = '正在蒸馏…';
      MI.ai.distill({ corpus: MI.fear.corpus(), archetypes: MI.fear.archetypes(), focus: MI.fear.derive().focus })
        .then(function (result) {
          MI.store.update(function (s) { s.fear.distilled = result; });
          paintAll(root);
          d.toast('重新蒸馏完成。接下来的对话会用上新句子。');
        })
        .catch(function (err) {
          paintAll(root);
          d.toast('蒸馏失败：' + err.message, 5000);
        });
    });

    var resetBtn = root.querySelector('#reset-fear');
    if (resetBtn) {
      resetBtn.addEventListener('click', function () {
        MI.fear.reset();
        MI.session.clear();
        MI.router.render();
        d.toast('这段对话已重置，它会从你的记录重新长出来。');
      });
    }
  }

  MI.views.fear = {
    title: '恐惧模型',
    render: render,
    mount: mount
  };
})(window.MI);
