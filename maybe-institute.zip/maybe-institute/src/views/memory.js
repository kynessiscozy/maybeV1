window.MI = window.MI || {};
(function (MI) {
  'use strict';
  MI.views = MI.views || {};

  var d = MI.dom;
  var pendingClear = null;

  function render() {
    var s = MI.store.get();
    var facts = MI.memory.facts();
    var rank = MI.memory.themeRanking();
    var evo = MI.evolution.log();
    var fb = MI.feedback.log();
    var hist = MI.memory.history();

    var factRows = facts.length ? facts.map(function (f) {
      return '<div class="fact">' +
        '<span class="fact-label">' + d.esc(f.label) + '</span>' +
        '<span class="fact-value">' + d.esc(f.value) + '</span>' +
        (f.kind === 'care'
          ? '<button class="fact-remove" data-forget-care="' + f.index + '" aria-label="忘记这条">×</button>'
          : '<span style="width:14px"></span>') +
        '</div>';
    }).join('') : '<p class="page-desc">还没有记住任何事。去实验室写下一个念头，或者在这里先告诉它你是谁。</p>';

    var bars = rank.length ? rank.map(function (t) {
      return '<div class="bar-row">' +
        '<span class="bar-name">' + d.esc(t.label) + '</span>' +
        '<span class="bar-track"><span class="bar-fill" style="width:' + Math.round(t.share * 100) + '%"></span></span>' +
        '<span class="bar-value">' + t.count + ' 次</span>' +
        '</div>';
    }).join('') : '<p class="page-desc">写下念头后，这里会显示你的注意力落在哪些主题上。</p>';

    var evoList = evo.length ? evo.map(function (l) {
      return '<div class="evo-item">' +
        '<p class="evo-trigger">' + d.esc(l.trigger) + '</p>' +
        '<p class="evo-change">' + d.esc(l.change) + '</p>' +
        '<p class="evo-meta">REV ' + l.revision + ' &nbsp;·&nbsp; ' + d.esc(d.relativeDay(l.date)) + '</p>' +
        '</div>';
    }).join('') : '<p class="page-desc">还没有触发过自我调整。给它几次反馈，这里就会出现变更记录。</p>';

    var fbList = fb.length ? fb.map(function (l) {
      return '<div class="log-item">' +
        '<span class="log-date">' + d.esc(d.relativeDay(l.date)) + '</span>' +
        '<span class="log-body"><strong>' + d.esc(l.text) + '</strong>' +
        (l.detail ? '<span>' + d.esc(l.detail) + '</span>' : '') + '</span>' +
        '</div>';
    }).join('') : '<p class="page-desc">还没有收到反馈。在路线详情页告诉它「像不像你」，它就会开始调整。</p>';

    var histList = hist.length ? hist.map(function (h, i) {
      var realIndex = s.observed.history.length - 1 - i;
      return '<div class="history-item">' +
        '<span class="history-main">' +
        '<span class="history-idea">' + d.esc(h.idea) + '</span>' +
        '<span class="history-meta">' + d.esc(MI.data.THEMES[h.theme] ? MI.data.THEMES[h.theme].label : h.theme) +
        ' · 胆量 ' + h.courage + '% · ' + h.time + ' 分钟 · ' + d.esc(d.relativeDay(h.date)) + '</span>' +
        '</span>' +
        '<button class="fact-remove" data-forget-history="' + realIndex + '" aria-label="忘记这个念头">×</button>' +
        '</div>';
    }).join('') : '<p class="page-desc">还没有写下的念头。</p>';

    return '' +
      '<section class="page">' +
      '<div class="page-head">' +
      '<div class="eyebrow">WHAT IT REMEMBERS &nbsp;/&nbsp; 记忆账本</div>' +
      '<h1 class="page-title">事务所记得的你</h1>' +
      '<p class="page-desc">这些内容只存在这个浏览器里，你随时可以逐条删除或全部清空。' +
      '记忆的作用是让建议更贴身，不是给你建档。</p>' +
      '</div>' +

      '<div class="stat-row">' +
      '<div class="stat"><strong>' + s.observed.totalIdeas + '</strong><span>写下的念头</span></div>' +
      '<div class="stat"><strong>' + (s.feedback.routes.length + s.feedback.tasks.length) + '</strong><span>给出的反馈</span></div>' +
      '<div class="stat"><strong>v' + s.evolution.revision + '</strong><span>规则版本</span></div>' +
      '</div>' +

      '<div class="memory-grid">' +
      '<div>' +
      '<div class="panel">' +
      '<div class="panel-head"><div><h2>你希望它知道的事</h2>' +
      '<p>主动告诉它，比让它猜更准确。</p></div></div>' +
      '<div class="form-row"><label for="profile-name">怎么称呼你</label>' +
      '<input type="text" id="profile-name" maxlength="20" placeholder="留空也可以" value="' + d.esc(s.profile.name) + '"></div>' +
      '<div class="form-row"><label for="profile-cares">你在意的几件事</label>' +
      '<input type="text" id="profile-cares" placeholder="用顿号或逗号分隔，最多 6 项" value="' + d.esc(s.profile.cares.join('、')) + '">' +
      '<p class="hint">例如：稳定的作息、和家人的时间、不被评价的表达</p></div>' +
      '<button class="btn btn-soft" id="save-profile">记住这些</button>' +
      '</div>' +

      '<div class="panel">' +
      '<div class="panel-head"><div><h2>它观察到的</h2>' +
      '<p>来自你写下的念头，不需要你手动填写。</p></div></div>' +
      '<div class="fact-list">' + factRows + '</div>' +
      '</div>' +

      '<div class="panel">' +
      '<div class="panel-head"><div><h2>注意力分布</h2>' +
      '<p>你写下的念头落在哪些主题上。</p></div></div>' +
      '<div class="bar-list">' + bars + '</div>' +
      '</div>' +
      '</div>' +

      '<div>' +
      '<div class="panel">' +
      '<div class="panel-head"><div><h2>它为自己改了什么</h2>' +
      '<p>每次调整都记录原因，可以一键回滚。这不是机器学习，是可解释的规则。</p></div>' +
      (evo.length ? '<button class="text-btn" id="reset-evolution">回滚到默认</button>' : '') +
      '</div>' +
      evoList +
      '</div>' +

      '<div class="panel">' +
      '<div class="panel-head"><div><h2>你给过的反馈</h2>' +
      '<p>最近 ' + Math.min(fb.length, 200) + ' 条，按时间倒序。</p></div>' +
      (fb.length ? '<button class="text-btn" id="clear-feedback">清空反馈</button>' : '') +
      '</div>' +
      '<div class="log-list">' + fbList + '</div>' +
      '</div>' +

      '<div class="panel">' +
      '<div class="panel-head"><div><h2>写过的念头</h2>' +
      '<p>最多保留最近 40 条。</p></div></div>' +
      '<div class="history-list">' + histList + '</div>' +
      '</div>' +

      '<div class="panel">' +
      '<div class="panel-head"><div><h2>数据管理</h2>' +
      '<p>所有内容都在你手上。</p></div></div>' +
      '<div class="switch-row">' +
      '<span><span class="switch-label">清空记忆与反馈</span>' +
      '<span class="switch-hint">保留档案柜与当前工作台，只忘掉学到的偏好。</span></span>' +
      '<button class="btn btn-ghost" id="clear-learning">清空</button>' +
      '</div>' +
      '<div class="switch-row">' +
      '<span><span class="switch-label">导出全部数据</span>' +
      '<span class="switch-hint">得到一个 JSON 文件，可备份或迁移到别的浏览器。</span></span>' +
      '<button class="btn btn-ghost" id="export-data">导出</button>' +
      '</div>' +
      '<div class="switch-row">' +
      '<span><span class="switch-label">导入数据</span>' +
      '<span class="switch-hint">从备份文件恢复，会覆盖当前全部内容。</span></span>' +
      '<button class="btn btn-ghost" id="import-data">导入</button>' +
      '</div>' +
      '<div class="switch-row">' +
      '<span><span class="switch-label">删除全部内容</span>' +
      '<span class="switch-hint">档案、记忆、反馈、设置一并清空，无法撤销。</span></span>' +
      '<button class="btn btn-danger" id="clear-all">删除</button>' +
      '</div>' +
      '<input type="file" id="import-file" accept="application/json,.json" hidden>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '</section>';
  }

  function mount(root) {
    root.querySelector('#save-profile').addEventListener('click', function () {
      var cares = root.querySelector('#profile-cares').value
        .split(/[、,，;；]/)
        .map(function (t) { return t.trim(); })
        .filter(Boolean);
      MI.memory.setProfile({ name: root.querySelector('#profile-name').value.trim(), cares: cares });
      MI.router.render();
      d.toast('记住了。之后展开建议时会带上这些。');
    });

    root.querySelector('.fact-list').addEventListener('click', function (e) {
      var btn = e.target.closest('[data-forget-care]');
      if (!btn) return;
      var idx = Number(btn.dataset.forgetCare);
      var cares = MI.store.get().profile.cares.slice();
      cares.splice(idx, 1);
      MI.memory.setProfile({ cares: cares });
      MI.router.render();
      d.toast('已忘记这一条。');
    });

    root.querySelector('.history-list').addEventListener('click', function (e) {
      var btn = e.target.closest('[data-forget-history]');
      if (!btn) return;
      MI.memory.forgetHistory(Number(btn.dataset.forgetHistory));
      MI.router.render();
      d.toast('已忘记这个念头。');
    });

    var resetBtn = root.querySelector('#reset-evolution');
    if (resetBtn) {
      resetBtn.addEventListener('click', function () {
        MI.evolution.reset();
        MI.router.render();
        d.toast('规则已回滚到默认状态。');
      });
    }

    var clearFb = root.querySelector('#clear-feedback');
    if (clearFb) {
      clearFb.addEventListener('click', function () {
        MI.feedback.clear();
        MI.router.render();
        d.toast('反馈已清空，规则也随之回滚。');
      });
    }

    root.querySelector('#clear-learning').addEventListener('click', function () {
      MI.store.clearLearning();
      MI.session.clear();
      MI.router.render();
      d.toast('记忆与反馈已清空，档案柜保留。');
    });

    root.querySelector('#export-data').addEventListener('click', function () {
      var blob = new Blob([MI.store.exportJSON()], { type: 'application/json;charset=utf-8' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = '未发生事务所-数据备份.json';
      a.rel = 'noopener';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 10000);
      d.toast('已开始导出数据备份。');
    });

    var fileInput = root.querySelector('#import-file');
    root.querySelector('#import-data').addEventListener('click', function () { fileInput.click(); });
    fileInput.addEventListener('change', function () {
      var file = fileInput.files && fileInput.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function () {
        try {
          MI.store.importJSON(String(reader.result));
          MI.session.clear();
          MI.router.render();
          d.toast('数据已恢复。');
        } catch (err) {
          d.toast('这个文件读不出来，请确认是本站导出的备份。');
        }
      };
      reader.readAsText(file);
    });

    root.querySelector('#clear-all').addEventListener('click', function () {
      if (pendingClear !== 'yes') {
        pendingClear = 'yes';
        var btn = root.querySelector('#clear-all');
        btn.textContent = '确认删除全部？';
        return;
      }
      MI.store.clearAll();
      MI.session.clear();
      pendingClear = null;
      MI.router.render();
      d.toast('已删除全部内容。');
    });
  }

  MI.views.memory = {
    title: '记忆',
    render: render,
    mount: mount
  };
})(window.MI);
