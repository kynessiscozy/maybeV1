window.MI = window.MI || {};
(function (MI) {
  'use strict';
  MI.views = MI.views || {};

  var d = MI.dom;

  MI.views.landing = {
    title: '入口',

    render: function () {
      var last = MI.memory.lastIdea();
      var def = MI.memory.preferredDefaults();
      var s = MI.store.get();
      var engine = MI.ai.isConfigured() ? '模型 + 本地规则' : '本地规则引擎';

      var meta = [
        ['数据去向', '只留在本浏览器'],
        ['当前引擎', engine],
        ['已存档案', s.saved.length + ' 份'],
        ['写下的念头', s.observed.totalIdeas + ' 个']
      ].map(function (row) {
        return '<div><span>' + d.esc(row[0]) + '</span><strong>' + d.esc(row[1]) + '</strong></div>';
      }).join('');

      var returnNote = last ? (
        '<div class="return-note">' +
        '<span>WELCOME BACK</span>' +
        '<p>上次你在想：' + d.esc(d.truncate(last.idea, 34)) + '<br>' +
        '来自 ' + d.esc(d.relativeDay(last.date)) + '。' +
        (def.time ? '你习惯每天借出 ' + def.time + ' 分钟。' : '') +
        '</p></div>'
      ) : '';

      return '' +
        '<section class="landing">' +
        '<div class="landing-inner">' +
        '<div>' +
        '<div class="eyebrow">EST. IN THE NOT-YET &nbsp;/&nbsp; 为尚未发生的你而设</div>' +
        '<h1>在另一种可能里，<br>你会<em>成为谁？</em></h1>' +
        '<p class="landing-lede">' +
        '收留一个不合时宜的念头，让它长出几条不同的路。<br>' +
        '不必改变一生。先借给自己七天。' +
        '</p>' +
        '<div class="landing-actions">' +
        '<button class="btn btn-primary" data-nav="/lab">进入可能性实验室' +
        '<svg viewBox="0 0 20 20" fill="none"><path d="M3 10h13m-5-5 5 5-5 5" stroke="currentColor" stroke-width="1.5"/></svg>' +
        '</button>' +
        '<button class="text-btn" data-nav="/memory">它记得我什么？</button>' +
        '</div>' +
        '</div>' +
        '<aside class="landing-aside">' +
        '<p class="landing-quote">未来不是一道单选题。<br>而你，还没有定稿。</p>' +
        '<div class="landing-meta">' + meta + '</div>' +
        returnNote +
        '</aside>' +
        '</div>' +
        '</section>';
    }
  };
})(window.MI);
