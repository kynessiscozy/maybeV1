window.MI = window.MI || {};
(function (MI) {
  'use strict';
  MI.views = MI.views || {};

  var d = MI.dom;

  function parseRoute(ctx) {
    var n = Number(ctx.params.index);
    return Number.isInteger(n) && n >= 0 && n < 3 ? n : MI.store.get().session.route;
  }

  function render(ctx) {
    var route = parseRoute(ctx);
    var plan = MI.session.ensure();
    var data = plan.routes[route];

    var switcher = MI.data.ROUTE_NAMES.map(function (name, i) {
      return '<button data-switch="' + i + '"' + (i === route ? ' class="active"' : '') +
        ' aria-pressed="' + (i === route) + '">' + MI.data.ROUTE_LETTERS[i] + ' · ' + d.esc(name) + '</button>';
    }).join('');

    var steps = data.nodes.map(function (n, i) {
      return '<article class="step">' +
        '<div class="step-code"><span>0' + (i + 1) + ' / ' + d.esc(n.code) + '</span>' +
        MI.data.icon(i === 0 ? 'seed' : i === 1 ? 'people' : 'flag') + '</div>' +
        '<h3>' + d.esc(n.title) + '</h3>' +
        '<p>' + d.esc(n.advice) + '</p>' +
        '</article>';
    }).join('');

    var engineBadge = plan.engine === 'ai'
      ? '<span class="engine-badge ai">MODEL</span>'
      : '<span class="engine-badge">LOCAL</span>';

    return '' +
      '<section class="page">' +
      '<div class="crumb">' +
      '<button data-nav="/lab">实验室</button><span>/</span>' +
      '<span>' + d.esc(d.truncate(plan.idea, 26)) + '</span>' +
      '</div>' +
      '<div class="route-head">' +
      '<div>' +
      '<div class="route-code">ROUTE ' + MI.data.ROUTE_LETTERS[route] + ' / 0' + (route + 1) + ' ' + engineBadge + '</div>' +
      '<h1>' + d.esc(MI.data.ROUTE_NAMES[route]) + '</h1>' +
      '</div>' +
      '<div class="route-switch" role="group" aria-label="切换路线">' + switcher + '</div>' +
      '</div>' +

      '<div class="route-layout">' +
      '<div>' +
      '<p class="route-desc">' + d.esc(data.description) + '</p>' +
      '<div class="steps">' + steps + '</div>' +

      '<div class="days-panel">' +
      '<div class="days-head">' +
      '<div><h2>七天，让它真实一点。</h2>' +
      '<p id="plan-sub">每天以 ' + plan.time + ' 分钟为上限，可自由拆分。可以跳过，可以重来。</p></div>' +
      '<div class="progress-group"><div class="progress-track"><div class="progress-fill" id="progress-fill"></div></div>' +
      '<span id="progress-label">0 / 7</span></div>' +
      '</div>' +
      '<div class="days" id="days"></div>' +
      '<div class="completion-box" id="completion" hidden>' +
      '<strong>一件未发生的事，已经发生了。</strong>' +
      '你不必立刻做得更大。记下这七天里最想再来一次的瞬间，那就是下一条路的入口。' +
      '</div>' +
      '<div class="plan-note"><span>每天完成后可以顺手告诉它难度，下次会调整。</span>' +
      '<span id="plan-note-right">开始本身，就很了不起。</span></div>' +
      '</div>' +
      '</div>' +

      '<aside>' +
      '<div class="feedback-card">' +
      '<h3>这条路，像你吗？</h3>' +
      '<p>你的判断会被记住，用来调整以后推荐哪条路。只统计不同念头下的判断。</p>' +
      '<div class="seg" id="route-verdict" role="group" aria-label="对这条路的判断">' +
      MI.data.FEEDBACK_VERDICTS.map(function (v) {
        return '<button data-key="' + v.key + '" aria-pressed="false">' + d.esc(v.label) + '</button>';
      }).join('') +
      '</div>' +
      '<p class="feedback-hint" id="verdict-hint"></p>' +
      '</div>' +

      '<div class="panel" style="margin-top:18px">' +
      '<div class="panel-head"><div><h2>带走它</h2>' +
      '<p>存进档案柜，或导出一份可离线阅读的备忘录。</p></div></div>' +
      '<button class="btn btn-soft btn-block" id="save-btn">收藏这个版本的自己</button>' +
      '<button class="btn btn-ghost btn-block" id="export-btn" style="margin-top:10px">导出可能性备忘录</button>' +
      '<p class="feedback-hint" id="save-hint"></p>' +
      '</div>' +
      '</aside>' +
      '</div>' +
      '</section>';
  }

  // ── 局部刷新 ────────────────────────────────────────
  function paintDays(root) {
    var s = MI.store.get();
    var route = s.session.route;
    var plan = MI.session.ensure();
    var done = s.session.done[route] || [];

    root.querySelector('#days').innerHTML = plan.routes[route].days.map(function (text, i) {
      var isDone = done.indexOf(i) > -1;
      var level = MI.feedback.taskLevel(route, i);
      return '<div class="day-row' + (isDone ? ' completed' : '') + '" data-row="' + i + '">' +
        '<button class="day-main" data-day="' + i + '" aria-pressed="' + isDone + '">' +
        '<span class="check" aria-hidden="true">' + (isDone ? '✓' : '') + '</span>' +
        '<span><span class="day-number">DAY 0' + (i + 1) + '</span>' +
        '<span class="day-title">' + d.esc(text) + '</span></span>' +
        '</button>' +
        '<div class="day-feedback">' +
        '<div class="seg compact" role="group" aria-label="第 ' + (i + 1) + ' 天任务难度">' +
        MI.data.TASK_LEVELS.map(function (lv) {
          return '<button data-level="' + lv.key + '" data-day-index="' + i + '" aria-pressed="' +
            (level === lv.key) + '">' + d.esc(lv.label) + '</button>';
        }).join('') +
        '</div></div>' +
        '</div>';
    }).join('');

    root.querySelector('#progress-label').textContent = done.length + ' / 7';
    root.querySelector('#progress-fill').style.width = (done.length / 7 * 100) + '%';
    root.querySelector('#completion').hidden = done.length !== 7;
    root.querySelector('#plan-note-right').textContent = done.length === 7
      ? '你已经把「如果」变成了「做过」。'
      : '开始本身，就很了不起。';
  }

  function paintVerdict(root) {
    var s = MI.store.get();
    var verdict = MI.feedback.routeVerdict(s.session.route, s.session.idea);
    root.querySelectorAll('#route-verdict button').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.dataset.key === verdict));
    });
    var stats = MI.feedback.routeStats()[s.session.route];
    var hint = root.querySelector('#verdict-hint');
    var bias = MI.evolution.bias()[s.session.route];
    var parts = [];
    parts.push('这条路上，你共留下 ' + (stats.like + stats.unlike + stats.unsure) + ' 次判断。');
    if (bias < 0) parts.push('目前它已被降权，不再被默认推荐。');
    if (bias > 0) parts.push('目前它在相近情况下会被优先推荐。');
    hint.textContent = parts.join(' ');
  }

  function paintSave(root) {
    var s = MI.store.get();
    var saved = s.saved.some(function (x) { return x.id === s.session.savedId; });
    var btn = root.querySelector('#save-btn');
    btn.textContent = saved ? '已收藏 · 进度会自动更新' : '收藏这个版本的自己';
    btn.className = 'btn btn-block ' + (saved ? 'btn-ghost' : 'btn-soft');
    root.querySelector('#save-hint').textContent = MI.store.isStorageOK()
      ? '收藏只保存在当前浏览器；重要的念头，记得导出带走。'
      : '浏览器未允许保存，请立即导出，否则刷新后会丢失。';
  }

  function paintAll(root) {
    paintDays(root);
    paintVerdict(root);
    paintSave(root);
  }

  function save(root) {
    var s = MI.store.get();
    if (s.saved.some(function (x) { return x.id === s.session.savedId; })) {
      MI.store.update(function (st) {
        st.saved = st.saved.map(function (x) {
          return x.id === st.session.savedId
            ? { id: x.id, date: x.date, idea: st.session.idea, courage: st.session.courage, time: st.session.time, route: st.session.route, done: st.session.done }
            : x;
        });
      });
      d.toast('已经为你保留，之后的行动进度也会自动更新。');
      paintSave(root);
      return;
    }
    if (s.saved.length >= 100) {
      d.toast('档案柜已满。请先导出重要路线，再移除旧档案。');
      return;
    }
    var id = d.uid();
    MI.store.update(function (st) {
      st.session.savedId = id;
      st.saved.push({
        id: id,
        date: new Date().toISOString(),
        idea: st.session.idea,
        courage: st.session.courage,
        time: st.session.time,
        route: st.session.route,
        done: st.session.done
      });
    });
    paintSave(root);
    d.toast(MI.store.isStorageOK()
      ? '已放进私人档案柜。这个版本的你，不会被匆忙覆盖。'
      : '已暂存本次会话；浏览器无法持久保存，请导出。');
  }

  function mount(root, ctx) {
    var route = parseRoute(ctx);
    if (route !== MI.store.get().session.route) {
      MI.store.update(function (s) { s.session.route = route; });
    }

    root.querySelectorAll('[data-switch]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        MI.router.go('/route/' + btn.dataset.switch);
      });
    });

    root.querySelector('#days').addEventListener('click', function (e) {
      var levelBtn = e.target.closest('[data-level]');
      if (levelBtn) {
        MI.feedback.rateTask(MI.store.get().session.route, Number(levelBtn.dataset.dayIndex), levelBtn.dataset.level);
        paintAll(root);
        d.toast('记下了。它会据此调整下次的任务规模。');
        return;
      }
      var dayBtn = e.target.closest('[data-day]');
      if (!dayBtn) return;
      var idx = Number(dayBtn.dataset.day);
      MI.store.update(function (s) {
        var list = s.session.done[s.session.route];
        s.session.done[s.session.route] = list.indexOf(idx) > -1
          ? list.filter(function (i) { return i !== idx; })
          : list.concat(idx).sort(function (a, b) { return a - b; });
        // 已收藏的档案同步进度
        s.saved = s.saved.map(function (x) {
          return x.id === s.session.savedId
            ? { id: x.id, date: x.date, idea: s.session.idea, courage: s.session.courage, time: s.session.time, route: s.session.route, done: s.session.done }
            : x;
        });
      });
      paintAll(root);
      if (MI.store.get().session.done[MI.store.get().session.route].length === 7) {
        d.toast('恭喜。你已经让一件未发生的事，发生了。');
      }
    });

    root.querySelector('#route-verdict').addEventListener('click', function (e) {
      var btn = e.target.closest('[data-key]');
      if (!btn) return;
      MI.feedback.rateRoute(MI.store.get().session.route, btn.dataset.key, MI.store.get().session.idea);
      paintAll(root);
      d.toast('记住了。下次展开时，推荐会跟着变。');
    });

    root.querySelector('#save-btn').addEventListener('click', function () { save(root); });
    root.querySelector('#export-btn').addEventListener('click', function () { MI.exporter.downloadMemo(); });

    paintAll(root);
  }

  MI.views.route = {
    title: '路线详情',
    render: render,
    mount: mount
  };
})(window.MI);
