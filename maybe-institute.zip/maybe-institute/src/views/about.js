window.MI = window.MI || {};
(function (MI) {
  'use strict';
  MI.views = MI.views || {};

  var d = MI.dom;

  MI.views.about = {
    title: '它是什么',

    render: function () {
      var s = MI.store.get();
      return '' +
        '<section class="page">' +
        '<div class="page-head">' +
        '<div class="eyebrow">ABOUT &nbsp;/&nbsp; 它是什么，不是什么</div>' +
        '<h1 class="page-title">一间收留念头的小事务所</h1>' +
        '<p class="page-desc">把它当成一张能落脚的纸，而不是一台替你决定的机器。</p>' +
        '</div>' +

        '<div class="memory-grid">' +
        '<div>' +
        '<div class="panel">' +
        '<div class="panel-head"><div><h2>它做什么</h2>' +
        '<p>三件事，仅此而已。</p></div></div>' +
        '<div class="about-list">' +
        '<div><strong>展开。</strong>把你写下的念头，拆成三条强度不同的可能性路线，每条给出三个推进节点。</div>' +
        '<div><strong>落地。</strong>把其中一条变成七天可执行的小步骤，规模与你能借出的时间匹配。</div>' +
        '<div><strong>记住。</strong>保存你的判断与难度反馈，据此调整下次的推荐与任务规模。</div>' +
        '</div>' +
        '</div>' +

        '<div class="panel">' +
        '<div class="panel-head"><div><h2>它不做什么</h2>' +
        '<p>这几条比上面更重要。</p></div></div>' +
        '<div class="about-list">' +
        '<div><strong>不预测未来。</strong>没有成功概率，没有收入估计，没有命运暗示。</div>' +
        '<div><strong>不替代专业意见。</strong>涉及食品、场地、经营、健康、法律、财务的事项，请咨询相应专业人士并确认合规要求。</div>' +
        '<div><strong>不鼓励贸然投入。</strong>所有路线都刻意从可撤回的小动作开始。远期愿景不等于七天内实现。</div>' +
        '<div><strong>不替你下结论。</strong>它只提供选项和第一小步，选哪条、要不要继续，始终由你决定。</div>' +
        '</div>' +
        '</div>' +
        '</div>' +

        '<div>' +
        '<div class="panel">' +
        '<div class="panel-head"><div><h2>两个引擎</h2>' +
        '<p>默认的那个不需要配置，也不联网。</p></div></div>' +
        '<div class="about-list">' +
        '<div><strong>本地规则引擎（默认）。</strong>用关键词匹配 5 类主题，套用策划好的行动模板，并按你选的时间参数化。完全离线。</div>' +
        '<div><strong>模型接口（可选）。</strong>你在设置里填入兼容接口的地址、模型与密钥后，会把念头、记忆摘要与反馈作为提示词发出去，换取更贴身的版本。失败时自动回退到本地结果。</div>' +
        '<div>无论用哪个引擎，返回内容都会经过结构校验；不合格的部分回退到本地模板。</div>' +
        '</div>' +
        '</div>' +

        '<div class="panel">' +
        '<div class="panel-head"><div><h2>自进化是怎么回事</h2>' +
        '<p>说清楚，才值得信任。</p></div></div>' +
        '<div class="about-list">' +
        '<div>它没有训练模型，也没有学习你的行为轨迹。只有几条写死的规则：</div>' +
        '<div>累计两次以上「太难」→ 任务规模下调到 70%；两次以上「太简单」→ 上调到 140%。</div>' +
        '<div>某条路线在两个不同念头下都被判断「不太像我」→ 它不再被默认推荐。</div>' +
        '<div>每次调整都会写进「记忆」页的变更记录，说明原因，并且可以一键回滚。</div>' +
        '</div>' +
        '</div>' +

        '<div class="panel">' +
        '<div class="panel-head"><div><h2>你的数据</h2>' +
        '<p>当前状态。</p></div></div>' +
        '<div class="about-list">' +
        '<div>存有 ' + s.saved.length + ' 份档案、' + s.observed.totalIdeas + ' 个念头、' +
        (s.feedback.routes.length + s.feedback.tasks.length) + ' 条反馈。</div>' +
        '<div>全部保存在本浏览器的 localStorage，不上传。' +
        (MI.store.isStorageOK() ? '' : '<strong>但当前浏览器拒绝保存，刷新后会丢失，请立即导出。</strong>') + '</div>' +
        '<div>你可以随时在「记忆」页逐条删除、清空或导出。</div>' +
        '</div>' +
        '<button class="btn btn-ghost btn-block" data-nav="/memory" style="margin-top:16px">查看记忆账本</button>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</section>';
    }
  };
})(window.MI);
