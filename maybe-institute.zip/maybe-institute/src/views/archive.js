window.MI = window.MI || {};
(function (MI) {
  'use strict';
  MI.views = MI.views || {};

  var d = MI.dom;
  var pendingRemove = null;

  function render() {
    var saved = MI.store.get().saved;
    return '' +
      '<section class="page">' +
      '<div class="page-head">' +
      '<div class="eyebrow">THE PRIVATE ARCHIVE &nbsp;/&nbsp; 念头暂存处</div>' +
      '<h1 class="page-title">有些自己，值得留底。</h1>' +
      '<p class="page-desc">这里存着你曾经认真想过的可能性。收藏只保存在当前浏览器；' +
      '重要的念头，记得导出带走。共 ' + saved.length + ' 份。</p>' +
      '</div>' +
      '<div class="archive-grid" id="archive-grid"></div>' +
      '</section>';
  }

  function paint(root) {
    var saved = MI.store.get().saved;
    var grid = root.querySelector('#archive-grid');
    pendingRemove = null;

    if (!saved.length) {
      grid.innerHTML = '<div class="empty-state">' +
        '<svg viewBox="0 0 64 64" fill="none" aria-hidden="true">' +
        '<path d="M10 23h44v29H10zM16 13h32v10M22 5h20v8M25 33h14" stroke="currentColor" stroke-width="1.2"/>' +
        '<path d="M30 40v9m-4-5 4 5 4-5" stroke="#df632e" stroke-width="1.2"/></svg>' +
        '<h2>档案柜还空着，未来不是。</h2>' +
        '<p>在路线详情页点击「收藏这个版本的自己」，<br>给某一种可能性留一个位置。</p>' +
        '<button class="btn btn-primary" data-nav="/lab">去种下第一个念头</button>' +
        '</div>';
      return;
    }

    grid.innerHTML = saved.slice().reverse().map(function (s) {
      var done = (s.done && s.done[s.route] ? s.done[s.route].length : 0);
      return '<article class="archive-card">' +
        '<div class="archive-date">FILE / ' + d.esc(s.id.slice(-6).toUpperCase()) + ' &nbsp; ' + d.esc(d.formatDate(s.date)) + '</div>' +
        '<h3>' + d.esc(s.idea) + '</h3>' +
        '<p>' + d.esc(MI.data.ROUTE_NAMES[s.route]) + ' · ' + s.time + ' 分钟 / 天<br>' +
        '已迈出 ' + done + ' 个小步骤</p>' +
        '<div class="archive-actions">' +
        '<button data-open="' + d.esc(s.id) + '">继续这条路 ↗</button>' +
        '<button data-remove="' + d.esc(s.id) + '" aria-label="从档案柜移除：' + d.esc(s.idea) + '">移除</button>' +
        '</div></article>';
    }).join('');
  }

  function mount(root) {
    paint(root);

    root.querySelector('#archive-grid').addEventListener('click', function (e) {
      var openBtn = e.target.closest('[data-open]');
      if (openBtn) {
        var target = MI.store.get().saved.filter(function (x) { return x.id === openBtn.dataset.open; })[0];
        if (!target) return;
        MI.store.update(function (s) {
          s.session = {
            idea: target.idea,
            courage: target.courage,
            time: target.time,
            route: target.route,
            done: target.done.map(function (list) { return list.slice(); }),
            savedId: target.id
          };
        });
        MI.session.rebuild();
        MI.router.go('/route/' + target.route);
        d.toast('已打开这份可能性，之前的行动进度也在。');
        return;
      }

      var removeBtn = e.target.closest('[data-remove]');
      if (!removeBtn) return;
      var id = removeBtn.dataset.remove;
      if (pendingRemove !== id) {
        root.querySelectorAll('[data-remove]').forEach(function (b) {
          b.textContent = '移除';
          b.classList.remove('btn-danger');
        });
        pendingRemove = id;
        removeBtn.textContent = '确认移除？';
        removeBtn.classList.add('btn-danger');
        return;
      }
      MI.store.update(function (s) {
        s.saved = s.saved.filter(function (x) { return x.id !== id; });
        if (s.session.savedId === id) s.session.savedId = null;
      });
      paint(root);
      d.toast('已从档案柜移除；当前工作台的内容不会被清空。');
    });
  }

  MI.views.archive = {
    title: '私人档案柜',
    render: render,
    mount: mount
  };
})(window.MI);
