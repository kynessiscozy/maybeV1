window.MI = window.MI || {};
(function (MI) {
  'use strict';
  MI.views = MI.views || {};

  var d = MI.dom;
  var NODE_ROWS = [[20, 16.5, 22.5], [50, 49.5, 52.2], [78.5, 81, 82.2]];
  var NODE_COLS = [32.5, 58.5, 83.5];
  var ROUTE_CLASS = ['green', 'orange', 'blue'];

  var busy = false;

  function currentIdea() { return MI.store.get().session.idea; }
  function currentRoute() { return MI.store.get().session.route; }

  // ── 渲染 ────────────────────────────────────────────
  function renderComposer() {
    var s = MI.store.get().session;
    var top = MI.memory.topTheme();
    var chips = MI.data.SEEDS.map(function (seed, i) {
      var preferred = top && MI.generate.themeFor(seed.idea).key === top.key;
      return '<button type="button" class="sample-chip' + (preferred ? ' preferred' : '') +
        '" data-sample="' + i + '" title="' + (preferred ? '和你常写的主题接近' : '') + '">' +
        d.esc(seed.label) + '</button>';
    }).join('');

    return '' +
      '<form class="composer" id="composer" novalidate>' +
      '<div class="label-row"><label for="idea">如果，我想……</label><span class="tiny-code">THE SEED</span></div>' +
      '<div class="idea-wrap">' +
      '<textarea id="idea" maxlength="120" aria-describedby="idea-hint" placeholder="如果不用先证明自己，我最想试试什么？">' + d.esc(s.idea) + '</textarea>' +
      '<span class="char-count" id="char-count">0 / 120</span>' +
      '</div>' +
      '<div class="sample-head"><span id="idea-hint">或者，借一个念头</span>' +
      '<button type="button" class="text-btn" id="shuffle">换一批 <span aria-hidden="true">↗</span></button></div>' +
      '<div class="sample-chips" id="sample-chips">' + chips + '</div>' +
      '<div class="range-control">' +
      '<div class="control-label"><label for="courage">偏离惯性的程度</label><output id="courage-value" for="courage">' + s.courage + '%</output></div>' +
      '<input id="courage" type="range" min="0" max="100" value="' + s.courage + '" step="1">' +
      '<div class="range-captions"><span>轻轻试探</span><span>大胆一点</span></div>' +
      '</div>' +
      '<div class="time-control">' +
      '<div class="time-label" id="time-label">每天能借给自己</div>' +
      '<div class="time-switch" role="group" aria-labelledby="time-label">' +
      MI.data.TIME_PRESETS.map(function (t) {
        var on = t === s.time;
        return '<button type="button" data-time="' + t + '" aria-pressed="' + on + '"' +
          (on ? ' class="active"' : '') + '>' + t + ' 分钟</button>';
      }).join('') +
      '</div></div>' +
      '<button class="generate" type="submit" id="generate-btn">' +
      '<span id="generate-label">展开我的可能性</span>' +
      '<span class="key">Ctrl ↵</span>' +
      '<svg width="16" height="16" viewBox="0 0 20 20" fill="none" aria-hidden="true">' +
      '<path d="M3 10h13m-5-5 5 5-5 5" stroke="currentColor" stroke-width="1.5"/></svg>' +
      '</button>' +
      '<p class="privacy">' +
      '<svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><rect x="4" y="7" width="8" height="6" rx="1.2" stroke="currentColor"/><path d="M6 7V5a2 2 0 0 1 4 0v2" stroke="currentColor"/></svg>' +
      '<span id="privacy-text">念头只留在此浏览器，不上传</span></p>' +
      '</form>';
  }

  function renderMapShell() {
    var s = MI.store.get().session;
    return '' +
      '<div class="map-card">' +
      '<div class="map-header">' +
      '<div><div class="map-overline"><span aria-hidden="true">⌖</span> POSSIBILITY FIELD</div>' +
      '<h2 class="map-title" id="map-title">一颗念头，三种生长方式。</h2></div>' +
      '<div class="map-tools">' +
      '<span class="small-label" id="field-id">FIELD / 001</span>' +
      '<button class="icon-btn" id="map-help" aria-label="如何探索分岔图" title="如何探索分岔图">' +
      '<svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="6.5" stroke="currentColor"/><path d="M10 9v5" stroke="currentColor"/><circle cx="10" cy="6.4" r=".7" fill="currentColor"/></svg>' +
      '</button></div></div>' +
      '<div class="map-banner" id="map-banner" hidden></div>' +
      '<div class="field" id="field">' +
      '<svg class="field-lines" viewBox="0 0 1000 360" preserveAspectRatio="none" aria-hidden="true">' +
      '<ellipse class="field-guide" cx="515" cy="178" rx="381" ry="145" stroke-dasharray="2 7"/>' +
      '<path class="field-guide" d="M100 22v308M254 180h707" stroke-dasharray="2 7"/>' +
      '<path class="route-path" data-path="0" d="M100 180C195 180 188 72 330 72S488 59 590 59S754 81 865 81"/>' +
      '<path class="route-path" data-path="1" d="M100 180C193 180 228 180 330 180S485 178 590 178S757 188 865 188"/>' +
      '<path class="route-path" data-path="2" d="M100 180C190 180 182 283 330 283S475 292 590 292S753 296 865 296"/>' +
      '<circle cx="207" cy="180" r="3" fill="#df632e"/>' +
      '<path d="m185 176 5 4-5 4" stroke="#df632e" fill="none" stroke-width="1.1"/>' +
      '</svg>' +
      '<div class="origin"><div class="origin-circle">如果</div>' +
      '<div class="origin-label">此刻的你<small>YOU ARE HERE</small></div></div>' +
      '<div class="route-label" style="top:4%">' + d.esc(MI.data.ROUTE_LABELS[0]) + '</div>' +
      '<div class="route-label" style="top:33.5%">' + d.esc(MI.data.ROUTE_LABELS[1]) + '</div>' +
      '<div class="route-label" style="top:62.5%">' + d.esc(MI.data.ROUTE_LABELS[2]) + '</div>' +
      '<div id="nodes"></div>' +
      '<div class="map-stamp">NOT A PREDICTION.<br>AN INVITATION.</div>' +
      '<div class="field-footnote">每一个节点，都可以是新的开始 +</div>' +
      '</div>' +
      '<div class="map-bottom">' +
      '<div class="route-tabs" id="route-tabs" role="group" aria-label="选择探索路线"></div>' +
      '<span class="map-caption">点一个节点，看看它如何发生 ↗</span>' +
      '</div></div>';
  }

  function render() {
    return '' +
      '<section class="page">' +
      '<div class="page-head">' +
      '<div class="eyebrow">STEP 01 &nbsp;/&nbsp; 给可能性一个入口</div>' +
      '<h1 class="page-title">如果，我想……</h1>' +
      '<p class="page-desc">不需要一个好主意，只需要一个真念头。写下来，它会展开成三条不同强度的路。</p>' +
      '</div>' +
      '<div class="workspace">' + renderComposer() + renderMapShell() + '</div>' +
      '<div class="node-detail" id="node-detail" hidden aria-live="polite">' +
      '<div><strong id="node-detail-title"></strong><p id="node-detail-text"></p></div>' +
      '<button id="node-close" aria-label="关闭节点详情">×</button>' +
      '</div>' +
      '<div class="section-bar" style="margin-top:26px">' +
      '<div class="section-title"><span class="section-number">02</span>从想象，到今天</div>' +
      '<button class="btn btn-ghost" id="open-route">查看这条路的七天安排' +
      '<svg viewBox="0 0 20 20" fill="none"><path d="M3 10h13m-5-5 5 5-5 5" stroke="currentColor" stroke-width="1.5"/></svg>' +
      '</button>' +
      '</div>' +
      '</section>';
  }

  // ── 局部刷新 ────────────────────────────────────────
  function paintNodes(root) {
    var plan = MI.session.ensure();
    var route = currentRoute();
    var theme = MI.data.THEMES[plan.theme] || MI.data.THEMES.general;

    root.querySelector('#nodes').innerHTML = plan.routes.map(function (r, ri) {
      return r.nodes.map(function (n, ni) {
        return '<button class="node route-' + ROUTE_CLASS[ri] + (ri === route ? ' active' : '') +
          '" data-node="' + ri + '-' + ni + '" style="left:' + NODE_COLS[ni] + '%;top:' + NODE_ROWS[ri][ni] + '%"' +
          ' aria-label="路线' + MI.data.ROUTE_LETTERS[ri] + '，' + d.esc(n.title) + '，查看建议">' +
          '<span class="node-meta"><span>' + MI.data.ROUTE_LETTERS[ri] + (ni + 1) + ' / ' + MI.data.NODE_STAGES[ni] + '</span>' +
          MI.data.icon(ni === 0 ? theme.icon : ni === 1 ? 'people' : 'flag') + '</span>' +
          '<span class="node-title">' + d.esc(n.title) + '</span>' +
          '<span class="node-sub">' + d.esc(n.code) + '</span>' +
          '</button>';
      }).join('');
    }).join('');

    root.querySelectorAll('[data-path]').forEach(function (p) {
      p.classList.toggle('selected', Number(p.dataset.path) === route);
    });
  }

  function paintRouteTabs(root) {
    var route = currentRoute();
    var bias = MI.evolution.bias();
    root.querySelector('#route-tabs').innerHTML = MI.data.ROUTE_NAMES.map(function (name, i) {
      var down = bias[i] < 0;
      return '<button class="route-tab' + (i === route ? ' active' : '') + (down ? ' downweighted' : '') +
        '" data-route="' + i + '" aria-pressed="' + (i === route) + '"' +
        ' title="' + (down ? '因为你曾判断这条路不太像你，它不再被默认推荐' : '') + '">' +
        '<i aria-hidden="true"></i>' + d.esc(name) + '</button>';
    }).join('');
  }

  function paintHeader(root) {
    var plan = MI.session.ensure();
    root.querySelector('#map-title').textContent = plan.themeLabel + '，三种生长方式。';
    root.querySelector('#map-title').classList.remove('draft');
    root.querySelector('#field-id').textContent = plan.fieldId;

    var banner = root.querySelector('#map-banner');
    var reason = plan.routeReason;
    var parts = [];
    if (reason) parts.push('<strong>已按你的反馈调整：</strong>' + d.esc(reason));
    if (plan.engine === 'ai') parts.push('这一版由你在设置里接入的模型生成。');
    if (parts.length) {
      banner.innerHTML = parts.join(' ');
      banner.hidden = false;
    } else {
      banner.hidden = true;
    }
  }

  function paintEngineBadge(root) {
    var ai = MI.ai.isConfigured();
    var dot = document.getElementById('engine-dot');
    var label = document.getElementById('engine-label');
    if (dot) dot.classList.toggle('warn', ai);
    if (label) label.textContent = ai ? '模型接口已启用' : '本地规则';
    var privacy = root.querySelector('#privacy-text');
    if (privacy) {
      privacy.textContent = ai
        ? '启用模型后，念头会发送到你指定的服务'
        : (MI.store.isStorageOK() ? '念头只留在此浏览器，不上传' : '浏览器未允许保存，请及时导出');
    }
  }

  function paintAll(root) {
    paintNodes(root);
    paintRouteTabs(root);
    paintHeader(root);
    paintEngineBadge(root);
  }

  // ── 交互 ────────────────────────────────────────────
  function updateCount(root) {
    var el = root.querySelector('#idea');
    root.querySelector('#char-count').textContent = el.value.length + ' / 120';
  }

  function markDraft(root) {
    var title = root.querySelector('#map-title');
    title.textContent = '新念头已就位，点击「展开」更新。';
    title.classList.add('draft');
  }

  function setBusy(root, isBusy, label) {
    busy = isBusy;
    var btn = root.querySelector('#generate-btn');
    if (!btn) return;
    btn.disabled = isBusy;
    root.querySelector('#generate-label').textContent = label || (isBusy ? '正在展开…' : '展开我的可能性');
  }

  function buildAIContext(plan) {
    var log = MI.feedback.log().slice(0, 6).map(function (l) { return l.text; });
    var log2 = MI.evolution.log().slice(0, 3).map(function (l) {
      return l.trigger + ' → ' + l.change;
    });
    return {
      idea: plan.idea,
      courage: plan.courage,
      time: plan.time,
      themeLabel: plan.themeLabel,
      memory: MI.memory.summary(),
      feedback: log,
      adjustment: log2.join('；')
    };
  }

  function generate(root) {
    if (busy) return;
    var ideaEl = root.querySelector('#idea');
    var idea = ideaEl.value.trim();
    if (!idea) {
      d.toast('哪怕只有一个词，也先把它写下来。');
      ideaEl.focus();
      return;
    }
    if (idea.length < 2) {
      d.toast('再多写一点点，让这个念头更具体。');
      ideaEl.focus();
      return;
    }

    var courage = Number(root.querySelector('#courage').value);
    var time = Number(root.querySelector('.time-switch .active').dataset.time);
    var before = MI.store.get().session;
    var sameIdea = idea === before.idea;

    var plan = MI.generate.local(idea, courage, time);

    MI.store.update(function (s) {
      s.session.idea = idea;
      s.session.courage = courage;
      s.session.time = time;
      s.session.route = plan.route;
      if (!sameIdea) {
        s.session.done = [[], [], []];
        s.session.savedId = null;
      }
    });
    MI.session.set(plan);
    MI.memory.recordIdea(idea, plan.theme, courage, time);
    MI.views.lab.closeNode(root);
    paintAll(root);

    if (!MI.ai.isConfigured()) {
      d.toast(sameIdea ? '你的可能性还在这里，进度也为你保留着。' : '三条可能性已经展开。选一条，不代表放弃另外两条。');
      return;
    }

    // 启用了模型：先给本地结果，再异步换成模型版本
    setBusy(root, true, '正在请模型展开…');
    var banner = root.querySelector('#map-banner');
    banner.innerHTML = '正在请求模型生成更贴身的版本，稍等片刻。本地版本已经可以先看。';
    banner.hidden = false;

    MI.ai.generate(buildAIContext(plan)).then(function (aiPlan) {
      MI.session.set(aiPlan);
      paintAll(root);
      d.toast('模型版本已生成。觉得哪里不对，随时去「记忆」页调整。');
    }).catch(function (err) {
      paintAll(root);
      d.toast('模型没能完成（' + err.message + '）。已保留本地规则的结果。', 5200);
    }).then(function () {
      setBusy(root, false);
    });
  }

  function openNode(root, route, node) {
    MI.store.update(function (s) { s.session.route = route; });
    var plan = MI.session.ensure();
    var n = plan.routes[route].nodes[node];
    paintAll(root);
    var el = root.querySelector('[data-node="' + route + '-' + node + '"]');
    if (el) el.classList.add('selected-node');
    root.querySelector('#node-detail-title').textContent =
      MI.data.ROUTE_LETTERS[route] + (node + 1) + ' / ' + n.title;
    root.querySelector('#node-detail-text').textContent = n.advice;
    root.querySelector('#node-detail').hidden = false;
  }

  function closeNode(root) {
    var panel = root.querySelector('#node-detail');
    if (panel) panel.hidden = true;
    root.querySelectorAll('.selected-node').forEach(function (n) { n.classList.remove('selected-node'); });
  }

  function mount(root) {
    var composer = root.querySelector('#composer');
    var ideaEl = root.querySelector('#idea');
    updateCount(root);

    ideaEl.addEventListener('input', function () { updateCount(root); markDraft(root); });

    root.querySelector('#courage').addEventListener('input', function (e) {
      root.querySelector('#courage-value').textContent = e.target.value + '%';
      markDraft(root);
    });

    composer.querySelector('.time-switch').addEventListener('click', function (e) {
      var btn = e.target.closest('[data-time]');
      if (!btn) return;
      composer.querySelectorAll('[data-time]').forEach(function (b) {
        var on = b === btn;
        b.classList.toggle('active', on);
        b.setAttribute('aria-pressed', String(on));
      });
      markDraft(root);
    });

    root.querySelector('#sample-chips').addEventListener('click', function (e) {
      var btn = e.target.closest('[data-sample]');
      if (!btn) return;
      ideaEl.value = MI.data.SEEDS[Number(btn.dataset.sample)].idea;
      updateCount(root);
      markDraft(root);
      ideaEl.focus();
    });

    root.querySelector('#shuffle').addEventListener('click', function () {
      var chips = root.querySelector('#sample-chips');
      var start = (Number(chips.dataset.offset || 0) + 3) % MI.data.SEEDS.length;
      chips.dataset.offset = start;
      var top = MI.memory.topTheme();
      chips.innerHTML = [0, 1, 2].map(function (i) {
        var idx = (start + i) % MI.data.SEEDS.length;
        var preferred = top && MI.generate.themeFor(MI.data.SEEDS[idx].idea).key === top.key;
        return '<button type="button" class="sample-chip' + (preferred ? ' preferred' : '') +
          '" data-sample="' + idx + '">' + d.esc(MI.data.SEEDS[idx].label) + '</button>';
      }).join('');
    });

    composer.addEventListener('submit', function (e) {
      e.preventDefault();
      generate(root);
    });

    root.querySelector('#route-tabs').addEventListener('click', function (e) {
      var btn = e.target.closest('[data-route]');
      if (!btn) return;
      MI.store.update(function (s) { s.session.route = Number(btn.dataset.route); });
      closeNode(root);
      paintAll(root);
    });

    root.querySelector('#nodes').addEventListener('click', function (e) {
      var btn = e.target.closest('[data-node]');
      if (!btn) return;
      var parts = btn.dataset.node.split('-').map(Number);
      openNode(root, parts[0], parts[1]);
    });

    root.querySelector('#node-close').addEventListener('click', function () { closeNode(root); });
    root.querySelector('#map-help').addEventListener('click', function () { MI.app.openHelp(); });
    root.querySelector('#open-route').addEventListener('click', function () {
      MI.router.go('/route/' + MI.store.get().session.route);
    });

    paintAll(root);
  }

  MI.views.lab = {
    title: '实验室',
    render: render,
    mount: mount,
    closeNode: closeNode,
    refresh: function () {
      var root = document.getElementById('view');
      if (root && root.querySelector('#composer')) paintAll(root);
    }
  };
})(window.MI);
