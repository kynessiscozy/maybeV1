window.MI = window.MI || {};
(function (MI) {
  'use strict';

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function delegate(root, type, selector, handler) {
    root.addEventListener(type, function (e) {
      var target = e.target.closest(selector);
      if (target && root.contains(target)) handler(e, target);
    });
  }

  var toastTimer = null;
  function toast(text, ms) {
    var node = $('#toast');
    if (!node) return;
    clearTimeout(toastTimer);
    node.textContent = text;
    node.hidden = false;
    toastTimer = setTimeout(function () { node.hidden = true; }, ms || 3800);
  }

  function pad(n, width) {
    return String(n).padStart(width, '0');
  }

  function formatDate(iso) {
    try {
      return new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(iso));
    } catch (e) {
      return '日期未记录';
    }
  }

  function relativeDay(iso) {
    var then = new Date(iso);
    var now = new Date();
    var days = Math.floor((now - then) / 86400000);
    if (days <= 0) return '今天';
    if (days === 1) return '昨天';
    if (days < 7) return days + ' 天前';
    return formatDate(iso);
  }

  function uid() {
    if (window.crypto && window.crypto.randomUUID) return window.crypto.randomUUID();
    return String(Date.now()) + Math.random().toString(36).slice(2, 8);
  }

  function clamp(n, min, max) { return Math.min(max, Math.max(min, n)); }

  function truncate(text, len) {
    text = String(text || '');
    return text.length > len ? text.slice(0, len) + '…' : text;
  }

  MI.dom = {
    esc: esc, $: $, $$: $$, delegate: delegate, toast: toast,
    pad: pad, formatDate: formatDate, relativeDay: relativeDay,
    uid: uid, clamp: clamp, truncate: truncate
  };
})(window.MI);
