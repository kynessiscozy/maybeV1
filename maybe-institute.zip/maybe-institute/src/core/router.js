window.MI = window.MI || {};
(function (MI) {
  'use strict';

  var routes = [];
  var outlet = null;
  var active = null;
  var currentPath = null;

  function compile(pattern) {
    var keys = [];
    var regex = new RegExp('^' + pattern.replace(/:[A-Za-z0-9_]+/g, function (m) {
      keys.push(m.slice(1));
      return '([^/]+)';
    }).replace(/\//g, '\\/') + '$');
    return { regex: regex, keys: keys };
  }

  function define(pattern, view) {
    routes.push({ pattern: pattern, compiled: compile(pattern), view: view });
  }

  function match(path) {
    for (var i = 0; i < routes.length; i++) {
      var hit = routes[i].compiled.regex.exec(path);
      if (hit) {
        var params = {};
        routes[i].compiled.keys.forEach(function (k, idx) { params[k] = decodeURIComponent(hit[idx + 1]); });
        return { route: routes[i], params: params };
      }
    }
    return null;
  }

  function parseHash() {
    var raw = location.hash.replace(/^#/, '');
    if (!raw || raw === '/') return '/';
    return raw.replace(/\/+$/, '') || '/';
  }

  function render() {
    if (!outlet) return;
    var path = parseHash();
    var found = match(path) || match('/404');
    if (!found) return;

    var view = found.route.view;

    if (active && typeof active.view.unmount === 'function') {
      try { active.view.unmount(); } catch (e) { /* 忽略卸载异常 */ }
    }

    var ctx = { path: path, params: found.params, query: {} };
    var html;
    try {
      html = view.render(ctx);
    } catch (e) {
      html = '<section class="page"><h1 class="page-title">这一页没能展开</h1>' +
        '<p class="page-desc">渲染时出现了问题：' + MI.dom.esc(e && e.message) + '</p></section>';
    }

    outlet.innerHTML = html;
    active = { view: view, ctx: ctx };
    currentPath = path;

    document.title = (view.title ? view.title + ' · ' : '') + '未发生事务所';
    if (typeof view.mount === 'function') {
      try { view.mount(outlet, ctx); } catch (e) { /* 挂载异常不阻断导航 */ }
    }

    window.scrollTo({ top: 0, behavior: 'auto' });

    // 让键盘与读屏用户知道页面已切换
    var heading = outlet.querySelector('h1');
    if (heading) {
      heading.setAttribute('tabindex', '-1');
      try { heading.focus({ preventScroll: true }); } catch (e) { /* 某些浏览器不支持参数 */ }
    }

    MI.router.notify(path);
  }

  var navListeners = [];
  var samePageListeners = [];

  function go(path) {
    var next = '#' + path;
    if (location.hash === next) { render(); return; }
    location.hash = next;
  }

  function start(node) {
    outlet = node;
    window.addEventListener('hashchange', render);
    render();
  }

  MI.router = {
    define: define,
    go: go,
    start: start,
    render: render,
    current: function () { return currentPath; },
    params: function () { return active ? active.ctx.params : {}; },
    // 导航变化（用于高亮当前菜单）
    onChange: function (fn) { navListeners.push(fn); },
    notify: function (path) { navListeners.forEach(function (fn) { fn(path); }); }
  };
})(window.MI);
