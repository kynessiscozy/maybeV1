window.MI = window.MI || {};
(function (MI) {
  'use strict';

  var d = MI.dom;
  var focusBeforeModal = null;

  var NAV_MAP = {
    '/lab': '/lab',
    '/route': '/lab',
    '/fear': '/fear',
    '/archive': '/archive',
    '/memory': '/memory',
    '/settings': '/settings',
    '/about': '/settings'
  };

  // ── 未找到 ───────────────────────────────────────────
  MI.views = MI.views || {};
  MI.views.notFound = {
    title: '找不到这一页',
    render: function () {
      return '<section class="page">' +
        '<div class="page-head">' +
        '<div class="eyebrow">404</div>' +
        '<h1 class="page-title">这条路还没有发生。</h1>' +
        '<p class="page-desc">你访问的页面不存在。也许它属于另一种可能。</p>' +
        '</div>' +
        '<button class="btn btn-primary" data-nav="/lab">回到实验室</button>' +
        '</section>';
    }
  };

  // ── 导航高亮与计数 ───────────────────────────────────
  function syncNav(path) {
    var section = '/' + (path.split('/')[1] || '');
    var target = NAV_MAP[section] || null;
    d.$$('#nav button').forEach(function (btn) {
      var on = btn.dataset.nav === target;
      btn.classList.toggle('active', on);
      if (on) btn.setAttribute('aria-current', 'page');
      else btn.removeAttribute('aria-current');
    });
  }

  function syncCounts() {
    var s = MI.store.get();
    var archiveCount = document.getElementById('nav-archive-count');
    var memoryCount = document.getElementById('nav-memory-count');
    if (archiveCount) archiveCount.textContent = d.pad(s.saved.length, 2);
    if (memoryCount) memoryCount.textContent = d.pad(MI.memory.count(), 2);

    var dot = document.getElementById('engine-dot');
    var label = document.getElementById('engine-label');
    var ai = MI.ai.isConfigured();
    if (dot) dot.classList.toggle('warn', ai);
    if (label) label.textContent = ai ? '模型接口已启用' : '本地规则';
  }

  // ── 使用说明弹窗 ─────────────────────────────────────
  function openHelp() {
    var overlay = document.getElementById('help-overlay');
    if (!overlay || !overlay.hidden) return;
    focusBeforeModal = document.activeElement;
    overlay.hidden = false;
    document.body.style.overflow = 'hidden';
    var shell = document.getElementById('shell');
    if (shell) shell.inert = true;
    var close = document.getElementById('close-help');
    if (close) close.focus();
  }

  function closeHelp() {
    var overlay = document.getElementById('help-overlay');
    if (!overlay || overlay.hidden) return;
    overlay.hidden = true;
    document.body.style.overflow = '';
    var shell = document.getElementById('shell');
    if (shell) shell.inert = false;
    if (focusBeforeModal && focusBeforeModal.focus) focusBeforeModal.focus();
  }

  function trapTab(e) {
    var overlay = document.getElementById('help-overlay');
    if (!overlay || overlay.hidden) return;
    var items = d.$$('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])', overlay)
      .filter(function (el) { return !el.hidden && el.offsetParent !== null; });
    if (!items.length) return;
    var first = items[0];
    var last = items[items.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }

  // ── 键盘 ─────────────────────────────────────────────
  function bindKeyboard() {
    document.addEventListener('keydown', function (e) {
      var overlay = document.getElementById('help-overlay');
      var helpOpen = overlay && !overlay.hidden;
      var tag = document.activeElement ? document.activeElement.tagName : '';
      var editing = tag === 'INPUT' || tag === 'TEXTAREA';

      if (e.key === 'Escape') {
        if (helpOpen) { closeHelp(); return; }
        var root = document.getElementById('view');
        if (root) MI.views.lab.closeNode(root);
        return;
      }

      if (e.key === 'Tab' && helpOpen) { trapTab(e); return; }

      if (e.key === '?' && !editing && !helpOpen) {
        e.preventDefault();
        openHelp();
        return;
      }

      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter' && !helpOpen && MI.router.current() === '/lab') {
        e.preventDefault();
        var root = document.getElementById('view');
        var form = root && root.querySelector('#composer');
        if (form) form.requestSubmit ? form.requestSubmit() : form.dispatchEvent(new Event('submit', { cancelable: true }));
      }
    });
  }

  // ── 启动 ─────────────────────────────────────────────
  function boot() {
    MI.store.init();

    MI.router.define('/', MI.views.landing);
    MI.router.define('/lab', MI.views.lab);
    MI.router.define('/route/:index', MI.views.route);
    MI.router.define('/fear', MI.views.fear);
    MI.router.define('/archive', MI.views.archive);
    MI.router.define('/memory', MI.views.memory);
    MI.router.define('/settings', MI.views.settings);
    MI.router.define('/about', MI.views.about);
    MI.router.define('/404', MI.views.notFound);

    // 全局导航：任何带 data-nav 的元素都能跳转
    document.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-nav]');
      if (!btn) return;
      e.preventDefault();
      MI.router.go(btn.dataset.nav);
    });

    document.getElementById('help-button').addEventListener('click', openHelp);
    document.getElementById('footer-help').addEventListener('click', openHelp);
    document.getElementById('close-help').addEventListener('click', closeHelp);
    document.getElementById('start-exploring').addEventListener('click', function () {
      closeHelp();
      MI.router.go('/lab');
    });
    document.getElementById('help-overlay').addEventListener('click', function (e) {
      if (e.target === this) closeHelp();
    });

    MI.router.onChange(function (path) {
      syncNav(path);
      syncCounts();
    });

    MI.store.subscribe(syncCounts);
    bindKeyboard();

    MI.router.start(document.getElementById('view'));
    syncCounts();

    // 首次进入但没有指定路径时，停在入口页
    if (!location.hash) location.hash = '#/';
  }

  MI.app = { boot: boot, openHelp: openHelp, closeHelp: closeHelp, syncCounts: syncCounts };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})(window.MI);
