const http = require('http');

/* 本地假的 OpenAI 兼容服务，用来端到端验证模型接口：
   不需要真实密钥，也能确认请求构造、鉴权头、超时、错误处理和回退路径。 */

const PORT = Number(process.argv[2] || 4399);
const MODE = process.argv[3] || 'ok';

const plan = {
  themeLabel: '独立创作',
  routes: [0, 1, 2].map((i) => ({
    description: '模型生成的第 ' + (i + 1) + ' 条路线定位说明，用来验证结构校验与渲染。',
    nodes: [0, 1, 2].map((j) => ({
      title: '模型节点' + (i + 1) + '-' + (j + 1),
      code: 'MODEL NODE ' + (i + 1) + (j + 1),
      advice: '这是模型给出的建议文本，用于确认节点卡片能正确显示外部内容。'
    })),
    days: [0, 1, 2, 3, 4, 5, 6].map((d) => '模型第 ' + (d + 1) + ' 天任务')
  }))
};

http.createServer((req, res) => {
  // 浏览器直连第三方接口会受 CORS 限制，这里补上跨域头
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  let body = '';
  req.on('data', (c) => { body += c; });
  req.on('end', () => {
    const auth = req.headers.authorization || '';
    const record = {
      url: req.url,
      method: req.method,
      authOK: /^Bearer .+/.test(auth),
      authPrefix: auth.slice(0, 12),
      hasSystem: body.includes('路线设计师'),
      hasMemory: body.includes('长期记忆'),
      hasFeedback: body.includes('反馈'),
      bodyLen: body.length
    };
    console.log('REQ ' + JSON.stringify(record));

    if (MODE === 'unauthorized') {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: { message: 'Incorrect API key provided' } }));
    }
    if (MODE === 'badjson') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ choices: [{ message: { content: '这不是 JSON' } }] }));
    }
    if (MODE === 'slow') {
      return setTimeout(() => {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ choices: [{ message: { content: JSON.stringify(plan) } }] }));
      }, 120000);
    }
    if (MODE === 'fenced') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({
        choices: [{ message: { content: '```json\n' + JSON.stringify(plan) + '\n```' } }]
      }));
    }

    const isPing = body.includes('ping');
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      choices: [{ message: { content: isPing ? 'OK' : JSON.stringify(plan) } }]
    }));
  });
}).listen(PORT, () => console.log('mock model server on http://localhost:' + PORT + ' mode=' + MODE));
