const http=require('http'),fs=require('fs'),path=require('path');
const root='C:/Users/hukeze/WorkBuddy AI/2026-09-14-15-16-18/maybe-institute/outputs';
http.createServer((req,res)=>{
  let p=decodeURIComponent(req.url.split('?')[0]);
  if(p==='/')p='/index.html';
  fs.readFile(path.join(root,p),(err,data)=>{
    if(err){res.writeHead(404);return res.end('not found');}
    res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
    res.end(data);
  });
}).listen(4321,()=>console.log('serving on http://localhost:4321'));
