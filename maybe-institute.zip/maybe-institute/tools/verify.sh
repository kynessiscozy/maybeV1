#!/usr/bin/env bash
set -u
cd "C:/Users/hukeze/WorkBuddy AI/2026-09-14-15-16-18/maybe-institute" || exit 1
AB=./tools/ab.sh
pass=0; fail=0

check(){ if [ "$2" = "$3" ]; then echo "  ✓ $1"; pass=$((pass+1));
         else echo "  ✗ $1  期望=[$2] 实际=[$3]"; fail=$((fail+1)); fi; }
V(){ $AB eval "$1" 2>/dev/null | tr -d '\r' | sed 's/^"//;s/"$//;s/\\"/"/g'; }
J(){ $AB eval "$(cat "$1")" 2>/dev/null | tr -d '\r' | sed 's/^"//;s/"$//;s/\\"/"/g'; }
go(){ $AB eval "location.hash='#$1'" >/dev/null 2>&1; $AB wait 450 >/dev/null 2>&1; }
top(){ $AB eval "window.scrollTo(0,0)" >/dev/null 2>&1; $AB wait 200 >/dev/null 2>&1; }

echo "── 准备：1440×900，清空存储 ──"
$AB close --all >/dev/null 2>&1
sleep 1
$AB set viewport 1440 900 >/dev/null 2>&1
$AB open "http://localhost:4321/" >/dev/null 2>&1
$AB wait 1600 >/dev/null 2>&1
$AB eval "localStorage.clear()" >/dev/null 2>&1
$AB reload >/dev/null 2>&1
$AB wait 1600 >/dev/null 2>&1

echo "── A. 入口页：功能不再堆在首页 ──"
check "落在入口页"          "true"  "$(V "String(!!document.querySelector('.landing'))")"
check "首页不含工作台表单"   "false" "$(V "String(!!document.querySelector('#composer'))")"
check "首页不含七天计划"     "false" "$(V "String(!!document.querySelector('#days'))")"
check "首页不含恐惧对话"     "false" "$(V "String(!!document.querySelector('#chat-log'))")"
check "首页不含设置表单"     "false" "$(V "String(!!document.querySelector('#ai-key'))")"
check "导航有 5 个入口"      "5"     "$(V "document.querySelectorAll('#nav button').length")"
check "入口页无横向溢出"     "false" "$(V "String(document.documentElement.scrollWidth>window.innerWidth)")"

echo "── B. 路由：每个二级页面 ──"
go /lab
check "实验室有输入区"   "true"  "$(V "String(!!document.querySelector('#composer'))")"
check "实验室有分岔图"   "9"     "$(V "document.querySelectorAll('.node').length")"
check "实验室导航高亮"   "实验室" "$(V "document.querySelector('#nav button.active').textContent.trim()")"
check "标题随页面变化"   "实验室 · 未发生事务所" "$(V "document.title")"
go /route/1
check "路线详情有节点卡" "3"     "$(V "document.querySelectorAll('.step').length")"
check "路线详情有七天"   "7"     "$(V "document.querySelectorAll('.day-row').length")"
go /fear
check "恐惧模型有对话区" "true"  "$(V "String(!!document.querySelector('#chat-log'))")"
go /archive
check "档案柜为空态"     "true"  "$(V "String(!!document.querySelector('.empty-state'))")"
go /memory
check "记忆页有账本"     "true"  "$(V "String(!!document.querySelector('#corpus-list')||!!document.querySelector('.fact-list'))")"
go /settings
check "设置页有密钥输入" "true"  "$(V "String(!!document.querySelector('#ai-key'))")"
go /about
check "关于页有说明"     "true"  "$(V "String(!!document.querySelector('.about-list'))")"
go /不存在的页面
check "未知路径回落 404" "true"  "$(V "String(document.querySelector('.page-title').textContent.includes('没有发生'))")"

echo "── C. 实验室：生成与记忆 ──"
go /lab
$AB eval "var t=document.querySelector('#idea');t.value='把备忘录里的碎碎念，做成一本有人等待的独立杂志。';t.dispatchEvent(new Event('input',{bubbles:true}));" >/dev/null 2>&1
$AB scrollintoview '#generate-btn' >/dev/null 2>&1
$AB click '#generate-btn' >/dev/null 2>&1
$AB wait 700 >/dev/null 2>&1
check "生成后主题匹配"   "独立创作" "$(V "MI.session.ensure().themeLabel")"
check "生成后落到路线 B" "1"        "$(V "String(MI.store.get().session.route)")"
check "记忆记录了念头"   "1"        "$(V "String(MI.store.get().observed.totalIdeas)")"
check "导航记忆计数更新" "01"       "$(V "document.querySelector('#nav-memory-count').textContent")"

echo "── D. 路线详情：勾选与反馈 ──"
go /route/1
$AB scrollintoview '.days-panel' >/dev/null 2>&1
$AB click '[data-day="0"]' >/dev/null 2>&1
$AB click '[data-day="1"]' >/dev/null 2>&1
$AB wait 500 >/dev/null 2>&1
check "勾选后进度 2/7"   "2 / 7" "$(V "document.querySelector('#progress-label').textContent")"
$AB click '[data-level="hard"][data-day-index="0"]' >/dev/null 2>&1
$AB click '[data-level="hard"][data-day-index="1"]' >/dev/null 2>&1
$AB wait 600 >/dev/null 2>&1
check "两次太难后规则下调" "0.7" "$(V "String(MI.evolution.scale())")"
check "产生了进化记录"     "true" "$(V "String(MI.evolution.log().length>0)")"
$AB click '[data-key="unlike"]' >/dev/null 2>&1
$AB wait 400 >/dev/null 2>&1
check "路线反馈已记录"     "unlike" "$(V "MI.feedback.routeVerdict(MI.store.get().session.route, MI.store.get().session.idea)")"

echo "── E. 收藏与档案柜 ──"
$AB scrollintoview '#save-btn' >/dev/null 2>&1
$AB click '#save-btn' >/dev/null 2>&1
$AB wait 600 >/dev/null 2>&1
check "已收藏"           "1"  "$(V "String(MI.store.get().saved.length)")"
check "导航档案计数"     "01" "$(V "document.querySelector('#nav-archive-count').textContent")"
go /archive
check "档案柜有卡片"     "1"  "$(V "document.querySelectorAll('.archive-card').length")"
$AB click '.archive-card [data-open]' >/dev/null 2>&1
$AB wait 700 >/dev/null 2>&1
check "打开后回到路线页" "true" "$(V "String(document.querySelector('.day-row.completed')!==null)")"

echo "── F. 记忆页 ──"
go /memory
$AB eval "document.querySelector('#profile-name').value='测试';document.querySelector('#profile-cares').value='稳定的作息、不被评价的表达';document.querySelector('#save-profile').click();" >/dev/null 2>&1
$AB wait 700 >/dev/null 2>&1
check "称呼已记住"       "测试" "$(V "MI.store.get().profile.name")"
check "在意的事已记住"   "2"    "$(V "String(MI.store.get().profile.cares.length)")"
check "账本列出记忆条目" "true" "$(V "String(document.querySelectorAll('.fact').length>=4)")"
check "进化记录可见"     "true" "$(V "String(document.querySelectorAll('.evo-item').length>0)")"
check "反馈流水可见"     "true" "$(V "String(document.querySelectorAll('.log-item').length>0)")"
check "念头历史可见"     "true" "$(V "String(document.querySelectorAll('.history-item').length>0)")"

echo "── G. 恐惧模型：蒸馏与对话 ──"
go /fear
$AB wait 500 >/dev/null 2>&1
check "它先开口了"       "1"     "$(V "String(MI.fear.turns().length)")"
check "对话区渲染出气泡" "1"     "$(V "document.querySelectorAll('.chat-turn.fear').length")"
check "蒸馏报告有原型"   "true"  "$(V "String(document.querySelectorAll('.archetype').length>=5)")"
check "原型带真实依据"   "true"  "$(V "String(MI.fear.archetypes()[0].evidence.length>0)")"
$AB eval "document.querySelector('#chat-text').value='我写下这些不是为了给别人看，是因为我自己想弄清楚。';document.querySelector('#chat-form').requestSubmit();" >/dev/null 2>&1
$AB wait 800 >/dev/null 2>&1
check "对话轮数增加"     "3"     "$(V "String(MI.fear.turns().length)")"
check "渲染出我的话"     "1"     "$(V "document.querySelectorAll('.chat-turn.you').length")"
$AB click '[data-verdict="rebut"]' >/dev/null 2>&1
$AB wait 500 >/dev/null 2>&1
check "反驳计数已记"     "1"     "$(V "String(MI.store.get().fear.stats.rebut)")"
check "确定性下降"       "true"  "$(V "String(MI.fear.derive().certainty<0.55)")"
check "自进化有记录"     "true"  "$(V "String(MI.store.get().fear.model.log.length>0)")"

echo "── H. 危机内容的安全兜底 ──"
$AB eval "document.querySelector('#chat-text').value='我不想活了';document.querySelector('#chat-form').requestSubmit();" >/dev/null 2>&1
$AB wait 700 >/dev/null 2>&1
check "出现关怀卡片"     "1"     "$(V "document.querySelectorAll('.chat-turn.care').length")"
check "关怀卡片给出建议" "true"  "$(V "String(document.querySelector('.chat-turn.care p').textContent.includes('专业'))")"
check "未继续扮演恐惧"   "false" "$(V "String(MI.fear.turns().slice(-1)[0].role==='fear')")"

echo "── I. 模型接口：端到端（本地模拟服务）──"
go /settings
$AB eval "MI.ai.save({endpoint:'http://localhost:4399/v1',model:'mock-model',key:'test-key-123456',enabled:true});MI.router.render();" >/dev/null 2>&1
$AB wait 600 >/dev/null 2>&1
check "设置页显示已启用" "true" "$(V "String(MI.ai.isConfigured())")"
check "密钥被掩码显示"   "true" "$(V "String(MI.ai.maskKey().includes('••'))")"
check "顶栏引擎已更新"   "模型接口已启用" "$(V "document.querySelector('#engine-label').textContent")"
$AB scrollintoview '#ai-test' >/dev/null 2>&1
$AB click '#ai-test' >/dev/null 2>&1
$AB wait 1800 >/dev/null 2>&1
check "测试连接成功"     "true" "$(V "String(MI.ai.config().lastTest && MI.ai.config().lastTest.ok)")"
check "地址自动补全路径" "http://localhost:4399/v1/chat/completions" "$(V "MI.ai.resolveEndpoint('http://localhost:4399/v1')")"

echo "── J. 模型生成：提示词注入记忆 ──"
go /lab
$AB eval "var t=document.querySelector('#idea');t.value='做一个只在周日营业的咖啡角';t.dispatchEvent(new Event('input',{bubbles:true}));" >/dev/null 2>&1
$AB scrollintoview '#generate-btn' >/dev/null 2>&1
$AB click '#generate-btn' >/dev/null 2>&1
$AB wait 2500 >/dev/null 2>&1
check "方案来自模型"     "ai"   "$(V "MI.session.ensure().engine")"
check "模型节点已渲染"   "true" "$(V "String(document.querySelector('.node-title').textContent.includes('模型节点'))")"
check "模型七天已渲染"   "true" "$(V "String(document.querySelector('.day-title').textContent.includes('模型第'))")"
check "提示词含记忆段"   "true" "$(V "String(MI.ai.buildUserPrompt({idea:'x',courage:65,time:45,themeLabel:'t',memory:MI.memory.summary(),feedback:[]}).includes('长期记忆'))")"

echo "── K. 恐惧模型接入模型 ──"
go /fear
$AB wait 400 >/dev/null 2>&1
$AB eval "document.querySelector('#chat-text').value='我打算这周就把第一期做出来。';document.querySelector('#chat-form').requestSubmit();" >/dev/null 2>&1
$AB wait 2200 >/dev/null 2>&1
check "模型回了话"       "true" "$(V "String(MI.fear.turns().slice(-1)[0].engine==='ai')")"
$AB click '#distill-btn' >/dev/null 2>&1
$AB wait 2200 >/dev/null 2>&1
check "重新蒸馏完成"     "true" "$(V "String(!!MI.store.get().fear.distilled)")"
check "蒸馏结果含句子"   "true" "$(V "String(MI.store.get().fear.distilled.lines.length>0)")"

echo "── L. 模型报错时回退本地 ──"
$AB eval "MI.ai.save({endpoint:'http://localhost:4399/notexist/v1',model:'m',key:'k',enabled:true});" >/dev/null 2>&1
go /lab
$AB scrollintoview '#generate-btn' >/dev/null 2>&1
$AB click '#generate-btn' >/dev/null 2>&1
$AB wait 2500 >/dev/null 2>&1
check "失败后回退本地"   "local" "$(V "MI.session.ensure().engine")"
check "失败后仍有内容"   "9"     "$(V "document.querySelectorAll('.node').length")"
$AB eval "MI.ai.save({endpoint:'',model:'',key:'',enabled:false});" >/dev/null 2>&1

echo "── M. 刷新持久化 ──"
$AB reload >/dev/null 2>&1
$AB wait 1800 >/dev/null 2>&1
check "刷新后档案还在"   "01" "$(V "document.querySelector('#nav-archive-count').textContent")"
check "刷新后记忆还在"   "测试" "$(V "MI.store.get().profile.name")"
check "刷新后恐惧对话还在" "true" "$(V "String(MI.fear.turns().length>=4)")"
check "刷新后进化仍在"   "0.7" "$(V "String(MI.evolution.scale())")"

echo "── N. 手机端 390×844 ──"
$AB close --all >/dev/null 2>&1
sleep 1
$AB set viewport 390 844 >/dev/null 2>&1
$AB open "http://localhost:4321/" >/dev/null 2>&1
$AB wait 1600 >/dev/null 2>&1
check "手机端无横向溢出" "false" "$(V "String(document.documentElement.scrollWidth>window.innerWidth)")"
go /lab
check "手机端实验室正常" "9" "$(V "document.querySelectorAll('.node').length")"
check "手机端地图无裁切" "" "$(V "JSON.stringify(Array.from(document.querySelectorAll('.node')).filter(function(n){var f=document.querySelector('#field').getBoundingClientRect();var r=n.getBoundingClientRect();return r.right>f.right+0.5||r.left<f.left-0.5;}).map(function(n){return n.querySelector('.node-title').textContent;}))" | tr -d '[]')"
go /fear
check "手机端对话正常"   "true" "$(V "String(!!document.querySelector('#chat-log'))")"
check "手机端无溢出(对话)" "false" "$(V "String(document.documentElement.scrollWidth>window.innerWidth)")"
$AB screenshot >/dev/null 2>&1
echo "  · 手机端截图已保存"

echo "── O. 控制台 ──"
$AB errors > /tmp/mi-err.log 2>&1
check "无脚本报错" "" "$(grep -v 'executable-path' /tmp/mi-err.log | tr -d '\r' | tr -d ' ' | sed 's/^✗//')"

echo
echo "结果：通过 $pass 项，失败 $fail 项"
exit $([ "$fail" -eq 0 ] && echo 0 || echo 1)
