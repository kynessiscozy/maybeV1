#!/usr/bin/env bash
# 浏览器验证包装器：ab <子命令...>
NODE="C:/Users/hukeze/.workbuddy-ai/binaries/node/versions/22.22.2-2/node.exe"
CLI="C:/Users/hukeze/.workbuddy-ai/binaries/node/workspace/node_modules/agent-browser/bin/agent-browser.js"
EDGE="C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
cd "C:/Users/hukeze/.workbuddy-ai/binaries/node/workspace" || exit 1
"$NODE" "$CLI" --session mi --executable-path "$EDGE" "$@"
